package com.example.invoice;
import Model.Invoice;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Controller
@RequestMapping("/invoice")
public class InvoiceController {

@ModelAttribute
@GetMapping
public String show_invoice(Invoice invoice){
    return "invoice";}
    @PostMapping
    public String processInvoice(@Valid Invoice invoice, Errors errors){
        if(errors.hasErrors()){
            return "invoice";
        }
        return "redirect:/";
    }
}
/*public String show_invoice(Model model){
    List<InvoicePojo> myList= Arrays.asList(

        new InvoicePojo("9941321317", "12/051991", "15/04/1992")
);


model.addAttribute("invoicehtml",myList);
return "invoicehtml";
}*/