package Model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
     @RequiredArgsConstructor
     public class Invoice {
         @NotBlank
         @Digits(integer=10,message="Invalid no",fraction=0)
         private String input_contact;
         @NotNull
         @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
         private Date startDate;
    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
    private Date endDate;

              }
